import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Signup from './components/signup';
import Login from './components/login';

function App() {
  return (
    <Routes>
      <Route path="/Signup" element={<Signup/>} />
      <Route path="/Login" element={<Login/>} />
      {/* Add other routes here */}
    </Routes>
  );
}

export default App;
